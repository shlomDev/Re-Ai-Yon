# InterviewCopilot

Development project for a Windows interview copilot that listens to interviewer audio, detects questions, and surfaces useful answer guidance in real time.

## Current state

The repository contains the **v6 prototype** created during development. It currently includes:

- Windows speaker/WASAPI loopback capture for interviewer audio
- Separate microphone capture
- Whisper transcription
- Question detection
- Answer-assistant GUI
- Windows master-sound safeguard
- Chrome helper for Google Meet mic/camera behavior
- Interview schedule configuration and pre-interview self-tests
- Current Google interview configuration
- A local-AI prototype backend

The local-AI backend is **not the final desired architecture**. See `PROJECT_STATE.md` and `docs/TARGET_ARCHITECTURE.md` before making changes.

## Target product

The target is provider-independent **InterviewCopilot** supporting Google Meet, Microsoft Teams, Zoom, Amazon Chime, Webex, and generic meeting applications. The answer view is the primary UI; transcript is secondary/hidden by default.

The configured answer backend is the user's **real signed-in ChatGPT Plus Windows app/session**, using the official Companion Window and guarded Windows UI Automation rather than Codex, a separate OpenAI API key, local AI, cookie extraction, or private ChatGPT endpoints. The official ChatGPT window is the answer pane; the application does not scrape responses.

## Platform support

The core application is cross-platform: Linux, macOS, and Windows can run the
GUI, audio capture, Whisper transcription, provider detection, question
segmentation, fallback answers, preflight, and tests. Windows additionally has
the implemented ChatGPT Companion UI Automation and Win32 window placement.
On Linux/macOS the application degrades safely to the built-in answer engine
until a native accessibility adapter is configured; it never pretends that
ChatGPT submission succeeded.

## Current milestone

The project now includes:

- automatic question submission to the official ChatGPT Windows Companion Window
- a safety check that refuses to type unless ChatGPT owns foreground focus
- built-in fallback answers if ChatGPT is unavailable
- provider-independent 63/37 side-by-side window geometry
- an answer-first prototype GUI with the transcript hidden
- automated unit tests and VS Code tasks

After setup on Windows, open and sign into the official ChatGPT app. Run the VS
Code task `Test ChatGPT Readiness`, followed by `Test ChatGPT Automatic
Submission`. The second task intentionally creates one test message in ChatGPT.

## Open in VS Code

Open this folder directly, or open:

`InterviewCopilot.code-workspace`

Start by reading:

1. `PROJECT_STATE.md`
2. `docs/TARGET_ARCHITECTURE.md`
3. `ROADMAP.md`
4. `AGENTS.md`

## VS Code tasks

- `Setup`
- `Run InterviewCopilot`
- `Run Full Test`
- `Run Answer UI Test`
- `Check Status`
- `Test ChatGPT Readiness`
- `Test ChatGPT Automatic Submission`
- `Run Unit Tests`
- `Python: compile project`

## Prototype quick test

The current v6 prototype files are intentionally kept at repository root so existing batch files continue to resolve relative paths.

See `docs/PROTOTYPE_V6_README.md` for the prototype-specific setup notes.

## Security

Do not commit API keys, authentication cookies, ChatGPT session tokens, browser profiles, recordings, transcripts, or interview output. See `.gitignore`.

## Answer-engine choices

Set `answer_engine.provider` in `assistant_settings.json` to `chatgpt_windows`,
`claude_desktop`, `anthropic`, `openai_compatible`, `ollama`, or `built_in`. Claude
Desktop uses your visible, normally signed-in Claude account, including Free plan;
the separate `anthropic` option uses the
documented Anthropic Messages API with `ANTHROPIC_API_KEY`; OpenAI-compatible
providers use a configured URL/model and `OPENAI_API_KEY`; Ollama runs locally.
All secrets stay in environment variables. No browser cookies or session tokens
are read.

## Language support

The transcriber uses multilingual Whisper with automatic language detection and
preserves Hebrew, English, and mixed Hebrew/English speech. The default
`large-v3-turbo` model is the practical broad-language choice for live use. For
Hebrew-only interviews, `ivrit-ai/whisper-large-v3-turbo-ct2` can be selected
manually for a Hebrew-specialized model. Answers are requested in the question's
language, and the large-text teleprompter supports Hebrew text.

Question detection does not require words such as “how,” “what,” or “איך.” The
live segmenter uses the end of the interviewer’s utterance (punctuation and
silence) so indirect questions and scenario-based prompts are handled too.
# Browser ChatGPT mode

The default answer engine is a visible signed-in ChatGPT browser window and works on Windows, macOS, and Linux. Install Playwright and Chromium (`pip install playwright` then `playwright install chromium`), start InterviewCopilot, and sign in normally in its dedicated profile. Questions are entered through visible UI only; cookies, tokens, and response text are never read.

## Real-interview privacy setup

The public project contains no personal interview history. Before a real interview, run `python setup_private_profile.py`, then edit the generated private files in the per-user application data directory. On Windows this is `%LOCALAPPDATA%/InterviewCopilot`; on macOS `~/Library/Application Support/InterviewCopilot`; on Linux `~/.local/share/InterviewCopilot`. Do not place recordings, transcripts, passwords, tokens, or confidential employer documents in the repository.

## Mass-user safety foundation

Each installation uses an isolated per-user data directory and can be redirected with `INTERVIEWCOPILOT_DATA_DIR` for managed deployments. Private profiles, interview schedules, settings, logs, and runtime transcripts are not shared between users. Run `python health_check.py` for a JSON readiness report suitable for support tooling.
