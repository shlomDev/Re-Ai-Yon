"""Create ignored local interview-data files from public templates."""
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
FILES = ("candidate_profile", "answer_bank", "interview_guidance", "interviews")
for stem in FILES:
    target = BASE / (stem + (".md" if stem != "answer_bank" and stem != "interviews" else ".json"))
    source = BASE / (stem + ".example" + target.suffix)
    if not target.exists():
        shutil.copyfile(source, target)
        print("created", target.name)
    else:
        print("kept", target.name)
print("Private files are local and ignored by Git.")
