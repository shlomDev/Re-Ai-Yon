"""Visible browser ChatGPT adapter using ordinary Playwright UI actions."""
from __future__ import annotations
import os
from dataclasses import dataclass
from chatgpt_windows import build_interview_prompt

@dataclass
class BrowserStatus:
    supported: bool
    ready: bool
    detail: str
    url: str = ""

class ChatGPTBrowserClient:
    def __init__(self, url="https://chatgpt.com/", user_data_dir=None, headless=False):
        self.url = url; self.user_data_dir = user_data_dir or os.path.join(os.path.expanduser("~"), ".interviewcopilot-chatgpt"); self.headless = headless
        self._context = self._page = self._pw = None
    def status(self):
        try: import playwright  # noqa: F401
        except ImportError: return BrowserStatus(False, False, "Install Playwright and Chromium for browser mode")
        return BrowserStatus(True, True, "Visible browser ready; sign in once in the dedicated profile", self.url)
    def _ensure_page(self):
        try: from playwright.sync_api import sync_playwright
        except ImportError as exc: raise RuntimeError("Browser mode requires Playwright: pip install playwright; playwright install chromium") from exc
        if self._page: return self._page
        self._pw = sync_playwright().start(); self._context = self._pw.chromium.launch_persistent_context(self.user_data_dir, headless=self.headless)
        self._page = self._context.pages[0] if self._context.pages else self._context.new_page(); self._page.goto(self.url, wait_until="domcontentloaded"); return self._page
    def submit_question(self, question):
        page = self._ensure_page(); composer = page.locator("#prompt-textarea, textarea[placeholder*='Message'], textarea").first
        composer.wait_for(state="visible", timeout=15000); composer.fill(build_interview_prompt(question)); composer.press("Enter"); return page.title() or "ChatGPT browser"
    def close(self):
        if self._context: self._context.close()
        if self._pw: self._pw.stop()
