# Roadmap

## P0 — Stabilize current prototype

- [ ] Run current v6 on the target Windows PC
- [ ] Verify WASAPI speaker capture with actual headset/speaker configuration
- [ ] Verify microphone capture
- [ ] Verify Windows master-volume safeguard
- [ ] Verify Whisper latency on target hardware
- [ ] Confirm Chrome extension does not accidentally toggle the wrong Meet control
- [ ] Add structured logging
- [ ] Add clean shutdown/recovery tests

## P1 — Replace local AI with ChatGPT Plus Windows integration

- [ ] Detect official ChatGPT Windows app/window
- [x] Build guarded Windows UI Automation proof-of-concept for ChatGPT input
- [ ] Open/reuse dedicated interview conversation
- [x] Add automatic supplied-question submission path (target-PC verification pending)
- [ ] Keep ChatGPT visible as right-side answer pane
- [x] Add provider-independent 63/37 layout engine (wiring/restore pending)
- [x] Remove Ollama/local-model requirement from configured normal answer path
- [ ] Keep a simple non-AI/manual fallback if ChatGPT app is unavailable

Success criterion: a simulated interviewer question reaches ChatGPT automatically with zero user clicks and the answer is visible without covering the meeting.

## P2 — Generic meeting detection

- [x] Introduce provider adapter interface
- [x] Add URL/process detectors for Meet, Teams, Zoom, Chime, Webex and generic fallback
- [ ] Google Meet adapter
- [ ] Microsoft Teams desktop/browser adapter
- [ ] Zoom desktop/browser adapter
- [ ] Amazon Chime adapter
- [ ] Webex adapter
- [ ] Generic call fallback based on scheduled interview + active PC audio

Success criterion: core transcription/answer code has no provider-specific imports.

## P3 — Better live question segmentation

- [ ] Reduce Whisper chunk latency without destabilizing CPU use
- [x] Add silence/end-of-turn detection
- [x] Merge partial transcript fragments into complete questions
- [x] Duplicate/near-duplicate suppression
- [ ] Ignore candidate microphone completely for question triggers

Success criterion: one answer request per interviewer question in realistic recorded-call tests.

## P4 — Automatic interview discovery

- [ ] Supported local Google Calendar authentication
- [ ] Upcoming-event scanner
- [ ] Interview classifier
- [ ] Gmail/recruiter-email enrichment for missing links/details
- [ ] Meet/Teams/Zoom/Chime/Webex URL extraction
- [ ] Update local interview registry automatically
- [ ] Schedule preflight tests automatically

## P5 — Preflight / reliability

- [ ] 24-hour self-test
- [ ] 30-minute final self-test
- [ ] catch-up test after sleep/offline state
- [ ] ChatGPT app signed-in/readiness check
- [ ] meeting-provider readiness check
- [ ] actionable failure report

## P6 — UX

- [ ] answer-first UI
- [ ] transcript hidden by default
- [ ] small detected-question/status line
- [ ] window layout restoration after interview
- [ ] large readable answer font
- [ ] optional concise / technical answer modes configured before interview, not clicked per question
## Current milestone

- Visible signed-in ChatGPT browser adapter for Windows/macOS/Linux.
- Install Playwright + Chromium and sign in once in the dedicated profile.
