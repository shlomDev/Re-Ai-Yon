"""Load private interview data from local files without requiring them in Git."""
from __future__ import annotations
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def text(name: str, default: str = "") -> str:
    path = BASE / name
    try:
        return path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError):
        return default

def json_data(name: str, default):
    path = BASE / name
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return default
