const HEALTH_URL = "http://127.0.0.1:8765/extension-health";

async function health() {
  try {
    await fetch(HEALTH_URL, {
      method: "POST",
      mode: "cors",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({version: chrome.runtime.getManifest().version, ts: Date.now()})
    });
  } catch (_) {}
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("health", {periodInMinutes: 1});
  health();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("health", {periodInMinutes: 1});
  health();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "health") health();
});

chrome.alarms.create("health", {periodInMinutes: 1});
health();
