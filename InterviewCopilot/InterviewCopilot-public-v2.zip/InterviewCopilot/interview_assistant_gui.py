#!/usr/bin/env python
import json
import queue
import threading
import time
import tkinter as tk
from collections import deque
from tkinter import ttk
from pathlib import Path

from answer_engine import generate_answer, looks_like_question, ai_status
from question_segmenter import QuestionSegmenter
from teleprompter import Teleprompter

BASE = Path(__file__).resolve().parent
FEED = BASE / "live_transcript.jsonl"
MIC_FEED = BASE / "candidate_transcript.jsonl"
SETTINGS = json.loads((BASE / "assistant_settings.json").read_text(encoding="utf-8"))

class App:
    def __init__(self, root):
        self.root = root
        root.title("Interview Live Assistant — AUTO")
        root.geometry("700x760")
        root.minsize(480, 520)

        self.offset = 0
        self.recent = deque(maxlen=SETTINGS["live"].get("question_context_segments", 3))
        self.last_question = ""
        self.answer_generation = 0
        self.pending = queue.Queue()
        self.segmenter = QuestionSegmenter(
            min_chars=SETTINGS["live"].get("question_min_chars", 12),
            silence_seconds=SETTINGS["live"].get("question_silence_seconds", 1.0),
        )
        self.teleprompter = Teleprompter()

        outer = ttk.Frame(root, padding=10)
        outer.pack(fill="both", expand=True)

        status = ttk.Frame(outer)
        status.pack(fill="x", pady=(0, 8))

        ttk.Label(
            status,
            text="AUTO MODE",
            font=("Segoe UI", 12, "bold")
        ).pack(side="left")

        self.ai_var = tk.StringVar(value="Checking local AI...")
        ttk.Label(status, textvariable=self.ai_var).pack(side="right")

        # Transcript remains available to the process but is hidden in normal
        # interview mode. The answer is the primary surface.
        self.transcript = tk.Text(outer, height=1, wrap="word", font=("Segoe UI", 9))
        self.transcript.configure(state="disabled")

        ttk.Label(
            outer,
            text="Detected Question",
            font=("Segoe UI", 13, "bold")
        ).pack(anchor="w")

        self.question_var = tk.StringVar(value="Listening for the interviewer...")
        ttk.Label(
            outer,
            textvariable=self.question_var,
            wraplength=660,
            font=("Segoe UI", 11)
        ).pack(fill="x", pady=(4, 10), anchor="w")

        header = ttk.Frame(outer)
        header.pack(fill="x")
        ttk.Label(
            header,
            text="Suggested Answer — generated automatically",
            font=("Segoe UI", 13, "bold")
        ).pack(side="left")

        self.source_var = tk.StringVar(value="")
        ttk.Label(header, textvariable=self.source_var).pack(side="right")

        self.answer = tk.Text(
            outer, height=8, wrap="word", font=("Segoe UI", 22), padx=14, pady=14
        )
        self.answer.pack(fill="both", expand=True, pady=(4, 8))
        self.answer.insert(
            "1.0",
            "No clicking required. The answer will appear automatically when a question is detected."
        )
        self.answer.configure(state="disabled")
        self.progress_var = tk.StringVar(value="Teleprompter: waiting for answer")
        ttk.Label(outer, textvariable=self.progress_var, font=("Segoe UI", 10)).pack(anchor="w")

        ttk.Label(
            outer,
            text="The tool only listens for questions on the PC/Meet output channel; your microphone does not trigger answers."
        ).pack(anchor="w")

        self.root.after(200, self.poll_feed)
        self.root.after(200, self.poll_answers)
        threading.Thread(target=self.refresh_ai_status, daemon=True).start()

    def refresh_ai_status(self):
        try:
            st = ai_status()
            if st.get("provider") == "chatgpt_windows" and st.get("ready"):
                msg = "ChatGPT ready"
            elif st.get("provider") == "chatgpt_windows":
                msg = "ChatGPT unavailable — safe fallback active"
            elif st.get("running") and st.get("model_present"):
                msg = "Answer engine ready"
            else:
                msg = "Safe fallback active"
        except Exception:
            msg = "Fallback answer engine active"
        self.root.after(0, lambda: self.ai_var.set(msg))

    def append_transcript(self, stamp, text):
        self.transcript.configure(state="normal")
        self.transcript.insert("end", f"[{stamp}] {text}\n")
        self.transcript.see("end")
        self.transcript.configure(state="disabled")

    def candidate_question(self):
        if not self.recent:
            return ""
        # Try newest segment first. If question is split over chunks, combine
        # the most recent 2–3 segments and test those as well.
        items = list(self.recent)
        candidates = [items[-1]]
        if len(items) >= 2:
            candidates.append(items[-2] + " " + items[-1])
        if len(items) >= 3:
            candidates.append(items[-3] + " " + items[-2] + " " + items[-1])

        for c in candidates:
            c = " ".join(c.split()).strip()
            if looks_like_question(c):
                return c
        return ""

    def auto_request_answer(self, question):
        question = " ".join(question.split()).strip()
        if not question or question == self.last_question:
            return

        # Avoid regenerating on tiny Whisper expansions of the same question.
        if self.last_question and (
            question in self.last_question or self.last_question in question
        ):
            if abs(len(question) - len(self.last_question)) < 20:
                return

        self.last_question = question
        self.answer_generation += 1
        generation = self.answer_generation

        self.question_var.set(question)
        self.source_var.set("generating...")
        self.answer.configure(state="normal")
        self.answer.delete("1.0", "end")
        self.answer.insert("1.0", "Generating answer automatically...")
        self.answer.configure(state="disabled")

        def worker():
            started = time.time()
            try:
                ans, source = generate_answer(question)
                elapsed = time.time() - started
                self.pending.put((generation, question, ans, source, elapsed))
            except Exception as e:
                self.pending.put(
                    (generation, question, f"Answer generation error: {e}", "error", 0)
                )

        threading.Thread(target=worker, daemon=True).start()

    def poll_answers(self):
        try:
            while True:
                generation, q, ans, source, elapsed = self.pending.get_nowait()
                if generation != self.answer_generation:
                    continue
                self.question_var.set(q)
                self.source_var.set(f"{source} · {elapsed:.1f}s")
                self.answer.configure(state="normal")
                self.answer.delete("1.0", "end")
                self.answer.insert("1.0", ans)
                self.answer.configure(state="disabled")
                self.teleprompter.set_answer(ans)
                self.show_teleprompter()
                self.progress_var.set("Teleprompter: chunk 1 — speak naturally; it advances with your microphone")
        except queue.Empty:
            pass

        self.root.after(150, self.poll_answers)

    def poll_feed(self):
        if FEED.exists():
            try:
                size = FEED.stat().st_size
                if size < self.offset:
                    self.offset = 0
                    self.recent.clear()

                with FEED.open("r", encoding="utf-8") as f:
                    f.seek(self.offset)

                    got_new = False
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue

                        try:
                            item = json.loads(line)
                        except Exception:
                            continue

                        if item.get("speaker") != "interviewer":
                            continue

                        text = str(item.get("text", "")).strip()
                        stamp = str(item.get("stamp", ""))

                        if text:
                            got_new = True
                            self.append_transcript(stamp, text)
                            self.recent.append(text)
                            segment = self.segmenter.add(text)
                            if segment:
                                self.auto_request_answer(segment.text)

                    self.offset = f.tell()

                    if got_new:
                        q = self.candidate_question()
                        # The segmenter is authoritative. It does not require
                        # an interrogative starter: scenarios and indirect
                        # questions are submitted after a speech boundary.

                    silent = self.segmenter.flush_if_silent()
                    if silent:
                        self.auto_request_answer(silent.text)

            except Exception:
                pass

        self.root.after(250, self.poll_feed)
        self.root.after(250, self.poll_mic_feed)

    def show_teleprompter(self):
        self.answer.configure(state="normal")
        self.answer.delete("1.0", "end")
        self.answer.insert("1.0", self.teleprompter.current())
        self.answer.configure(state="disabled")

    def poll_mic_feed(self):
        if MIC_FEED.exists():
            try:
                with MIC_FEED.open("r", encoding="utf-8") as f:
                    lines = f.readlines()[-3:]
                for line in lines:
                    item = json.loads(line)
                    if self.teleprompter.observe(item.get("text", "")):
                        self.show_teleprompter()
                        self.progress_var.set(
                            f"Teleprompter: chunk {self.teleprompter.index + 1}/{len(self.teleprompter.chunks)}"
                        )
            except Exception:
                pass
        self.root.after(400, self.poll_mic_feed)

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
