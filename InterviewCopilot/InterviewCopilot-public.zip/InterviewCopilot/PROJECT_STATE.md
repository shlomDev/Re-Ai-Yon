# Project State / Development Handoff

Current milestone: visible signed-in ChatGPT browser adapter is the default cross-platform answer path. It submits through ordinary Playwright UI actions and leaves the browser as the answer pane; no cookies, tokens, or response scraping.

## Product name

**InterviewCopilot**

## Primary user experience

The important output is the **answer pane**, not the transcript.

Preferred layout during an interview:

- meeting application/window: left ~60–65%
- ChatGPT answer window: right ~35–40%
- windows side-by-side, **not overlaying each other**
- transcript hidden by default
- optionally show one small line with the detected interviewer question

The tool should operate automatically during an armed interview:

1. discover/schedule interview
2. prepare/test system before interview
3. detect meeting start
4. ensure Windows output is audible
5. capture interviewer PC audio separately from candidate microphone
6. transcribe interviewer audio in the background
7. detect a completed interviewer question
8. automatically submit the question to the answer backend
9. surface the answer immediately in the answer pane
10. stop/finalize after the interview ends

**No per-question button click should be required.**

## Desired answer backend

Final desired backend:

- user's **real ChatGPT Plus account**
- no Codex CLI install
- no separate OpenAI API key/billing dependency
- no local AI requirement
- no browser-cookie/session-token extraction
- no calls to undocumented/private ChatGPT endpoints

Candidate approach to investigate/implement:

- use the official ChatGPT Windows application signed into the user's normal account
- keep a dedicated interview conversation open
- use supported/ordinary Windows UI automation/accessibility to focus the ChatGPT app, submit the detected question automatically, and keep its response pane visible on the right
- do **not** scrape authentication/session data
- avoid fragile selectors where Windows accessibility/UI Automation can provide stable controls

Important unresolved engineering item: there is no supported generic Plus-account model API for arbitrary local Python programs. Therefore the ChatGPT Windows UI is currently the intended answer surface rather than programmatically pulling ChatGPT output back into the custom GUI.

## Meeting-provider scope

Do not design the core around Google Meet only.

Target providers:

- Google Meet (browser)
- Microsoft Teams (desktop/browser)
- Zoom (desktop/browser)
- Amazon Chime (desktop/browser)
- Cisco Webex
- Slack Huddles
- generic browser/desktop call fallback

Core audio/transcription/question logic must be provider-independent. Provider-specific code should only detect call state and optional controls such as mic/camera.

## Interview discovery target

Next major feature after generic provider detection:

- read upcoming Google Calendar events
- use recruiter/interview email when calendar data is incomplete
- identify likely interview events
- extract meeting URL/provider
- capture start/end time + timezone
- create/update local interview configuration automatically
- schedule system self-tests automatically
- arm only the discovered interview window

Local PC code will need its own supported OAuth/connector path; ChatGPT connector credentials are not available to local Python automatically.

## Audio behavior

Required:

- interviewer = Windows output/loopback stream
- candidate = microphone stream
- save separate streams plus optional mixed WAV
- only interviewer stream triggers question detection
- Windows master output must not be muted
- if Windows master volume is effectively zero, bring it to a safe minimum (prototype uses 20%)
- do not change an already-higher volume unnecessarily

Meeting control target:

- microphone: automatically ensure it is on when appropriate
- camera: **ask user**, do not silently enable it
- never bypass OS/browser permissions
- do not auto-click Join unless explicitly added later

## Pre-interview verification

Each discovered interview should get two checks:

- ~24 hours before
- ~30 minutes before

Checks should cover:

- watcher/service running
- selected/default speaker
- Windows output unmuted
- loopback capture
- microphone capture
- transcription engine/model available
- provider detector/extension integration where applicable
- ChatGPT answer path ready
- answer window positioning possible

If the PC was asleep at the exact scheduled test time, use a reasonable catch-up window.

## Current prototype

The repository root contains the v6 prototype. It still has Google-specific naming such as `auto_meet_watch.py` and contains an Ollama/local-model implementation. Treat that as prototype code to reuse selectively rather than the final product contract.

The current Google interview data is preserved in `interviews.json` as a development fixture.

## Implemented milestone — 2026-09-01

- Added `chatgpt_windows.py`: guarded Windows UI Automation for the official,
  already signed-in ChatGPT app. It opens/focuses the documented Companion
  Window, verifies ChatGPT still owns foreground focus, pastes a compact
  candidate-grounded prompt, and submits it automatically.
- No response scraping is used. The official ChatGPT window is the answer pane.
- ChatGPT Windows is now the configured primary answer provider. If it is not
  available, the built-in answer bank remains active without affecting the call.
- Added provider-independent side-by-side geometry and Windows layout support in
  `window_layout.py` (meeting 63%, answer 37% by default).
- Changed the prototype GUI to answer-first: transcript hidden, larger answer.
- Added readiness/submission test command and unit tests.
- Added `meetings.base` provider adapters and detectors for Meet, Teams, Zoom,
  Chime, Webex and generic calls.
- Added rolling `QuestionSegmenter` with completion punctuation, silence flush,
  and duplicate suppression; the GUI now uses it before automatic submission.
- Added credential-free discovery/registry parsing, provider-aware preflight,
  and a conservative window-manager session wrapper.
- Reduced watcher Whisper chunks from 5 seconds to 3 seconds to lower latency.
- Added explicit Linux/macOS capability reporting and portable `run_interviewcopilot.sh`
  / `run_tests.sh` entry points. Non-Windows platforms now report safe fallback
  behavior instead of being misidentified as broken Windows integrations.
- Added teleprompter mode: answers are split into short chunks and the active
  chunk advances when candidate microphone transcription matches most of it.
  Candidate speech is isolated to `candidate_transcript.jsonl` and cannot fire
  interviewer question detection.
- Added multilingual mode with automatic Whisper language detection, Hebrew
  question starters/fallback answers, Unicode teleprompter matching, and
  `large-v3-turbo` as the practical multilingual default.
- Removed interrogative-starter gating from live question segmentation. Complete
  interviewer utterances now submit based on punctuation/silence boundaries,
  including indirect questions and scenario statements.
- Added `interview_guidance.md` from the Google and Microsoft prep PDFs found in
  email. Answer prompting now distinguishes technical reasoning from behavioral
  competency answers: STARL is used only when appropriate.
- Added `claude_desktop` as a visible signed-in desktop provider. Claude Free
  accounts are supported by Claude Desktop chat; API keys are not required for
  this UI path. Actual UI Automation still requires target-PC validation.
- Added `provider_self_test.py` and a VS Code task that checks every provider
  without sending paid API requests. It reports readiness separately for the
  selected provider and safe fallback.

Verified in this development environment: Python compilation and pure logic/unit
tests. Not yet verified here: the official ChatGPT app accessibility tree,
foreground focus, actual submission, and Win32 window movement. These require
the target Windows PC.

## What remains / known problems

- Run `Test ChatGPT Automatic Submission` on Windows with the signed-in ChatGPT
  app open. App updates can change its accessibility behavior.
- Wire meeting-window detection to `arrange_windows()` and capture/restore the
  original window rectangles at interview end.
- Replace Google-only watcher/extension coupling with meeting provider adapters.
- Replace fixed 5-second Whisper batching with VAD/end-of-turn segmentation.
- Scheduled self-test still treats local Ollama as mandatory and must be updated
  to test the selected answer provider.

## Exact next step

On the Windows PC, run Setup, open/sign into the official ChatGPT app, then run
`Test ChatGPT Automatic Submission`. Use that result to lock the UIA control
path, then connect provider detection to safe side-by-side layout/restore.

## Known product concern

Recording, transcription, and real-time AI assistance can be governed by local law, employer rules, and interview policies. Keep the product capable of disabling recording and/or answer assistance independently, and make these modes explicit in configuration.
