"""Fast, non-invasive readiness checks used before an interview."""
from __future__ import annotations
import json
from pathlib import Path
from discovery.registry import validate_interview
from meetings.base import MeetingContext, detect_provider

BASE = Path(__file__).resolve().parent

def run_preflight(item: dict) -> list[dict]:
    results = []
    errors = validate_interview(item)
    results.append({"name": "interview configuration", "ok": not errors,
                    "detail": "; ".join(errors) if errors else "valid"})
    provider = detect_provider(MeetingContext(url=item.get("meeting_url", "")))
    results.append({"name": "meeting provider", "ok": provider != "generic",
                    "detail": provider})
    try:
        from answer_engine import ai_status
        st = ai_status()
        results.append({"name": "answer provider", "ok": bool(st.get("ready") or st.get("fallback_ready")),
                        "detail": st.get("detail", st.get("provider", "unknown"))})
    except Exception as exc:
        results.append({"name": "answer provider", "ok": False, "detail": str(exc)})
    return results

if __name__ == "__main__":
    data = json.loads((BASE / "interviews.json").read_text(encoding="utf-8"))
    for interview in data.get("interviews", []):
        print(interview.get("title"))
        for row in run_preflight(interview):
            print(("PASS" if row["ok"] else "FAIL"), row["name"], "-", row["detail"])
